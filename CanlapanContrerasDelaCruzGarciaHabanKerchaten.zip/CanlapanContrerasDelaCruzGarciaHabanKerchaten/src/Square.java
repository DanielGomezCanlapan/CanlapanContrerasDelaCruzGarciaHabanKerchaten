public class Square {
}
