public class Shape {
}
